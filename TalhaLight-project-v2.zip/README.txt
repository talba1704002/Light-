Talha Light - full-screen WebView app for the ESP32 light controller

1. Create a new GitHub repo and upload EVERYTHING from this zip (keep the folder structure,
   including the hidden ".github" folder).
2. Go to the repo > Actions > "Build Android APK" (runs on every push, or press "Run workflow").
3. When it finishes, open the run and download the artifact "TalhaLight-apk" -> TalhaLight.apk
4. Install on the phone (allow "install unknown apps").

The app now has its own native-feeling interface (Home + Schedule) bundled inside the APK:
app/src/main/assets/index.html. It talks to http://esplight.local through a Java bridge, so it works
over the controller's Wi-Fi with no CORS problems.

ESP32 endpoints live in ONE block at the top of the <script> in index.html ("const API"). If your
firmware uses different paths or field names, change them there (readState / readSched adapt fields).
Open index.html?demo in any browser to preview the UI with fake data.
Package: com.talha.light.app

Logo: the TALHA logo is a vector (app/src/main/res/drawable/splash_logo.xml, and talha_logo.svg
in the project root), so it never blurs or stretches on any screen size.
