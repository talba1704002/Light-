package com.talha.light.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Full-screen WebView shell for the ESP32 light controller.
 * The HTML UI lives on the ESP32 itself (it is served from the board), so the app
 * simply opens the board's address in a borderless full-screen WebView.
 */
public class WebViewActivity extends Activity {

        private static final String BASE_URL = "http://esplight.local";
    private static final String UI_URL = "file:///android_asset/index.html";
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private static final long MIN_SPLASH_MS = 1500;
    private static final long WIFI_WAIT_MS = 2500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private View splash;
    private View errorView;
    private TextView errorText;

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean started = false;
    private boolean pageFailed = false;
    private long splashShownAt;
    private boolean splashHidden = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        splashShownAt = System.currentTimeMillis();

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0B0D);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0B0D);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        buildErrorView();
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(-1, -1));

        buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        goImmersive();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                pageFailed = false;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                CookieManager.getInstance().flush();
                if (!pageFailed) {
                    errorView.setVisibility(View.GONE);
                    hideSplash();
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    pageFailed = true;
                    showError("Could not load the app screen.");
                    handler.postDelayed(autoRetry, 4000);
                }
            }
        });

        // Native dialogs so alert()/confirm() in the page work
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        bindToWifiThenLoad();
    }

    /** HTTP bridge: the bundled UI talks to the ESP32 through here (no CORS, always over Wi-Fi). */
    private class Bridge {
        @JavascriptInterface
        public void request(final int id, final String method, final String path, final String body) {
            io.execute(() -> {
                int status = 0; String text = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(BASE_URL + path).openConnection();
                    c.setConnectTimeout(3500);
                    c.setReadTimeout(5000);
                    c.setRequestMethod(method);
                    if (body != null && body.length() > 0 && !"GET".equals(method)) {
                        c.setDoOutput(true);
                        c.setRequestProperty("Content-Type", "application/json");
                        OutputStream o = c.getOutputStream();
                        o.write(body.getBytes("UTF-8"));
                        o.close();
                    }
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[2048]; int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        text = bo.toString("UTF-8");
                    }
                } catch (Exception e) {
                    status = 0;
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__native(" + id + "," + status + "," + JSONObject.quote(text) + ")";
                handler.post(() -> { if (!isFinishing()) web.evaluateJavascript(js, null); });
            });
        }
    }

    // ---------- networking ----------

    /** Android may send traffic over mobile data when the ESP Wi-Fi has no internet.
     *  Bind this app to the Wi-Fi network so http://esplight.local always goes through Wi-Fi. */
    private void bindToWifiThenLoad() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network n) {
                    try { cm.bindProcessToNetwork(n); } catch (Exception ignored) {}
                    handler.post(WebViewActivity.this::startLoad);
                }
            };
            cm.requestNetwork(req, netCb);
        } catch (Exception e) {
            startLoad();
            return;
        }
        handler.postDelayed(this::startLoad, WIFI_WAIT_MS); // no Wi-Fi? try anyway
    }

    private void startLoad() {
        if (started) return;
        started = true;
        web.loadUrl(UI_URL);
    }

    private final Runnable autoRetry = new Runnable() {
        @Override public void run() {
            if (pageFailed && !isFinishing()) reload();
        }
    };

    private void reload() {
        handler.removeCallbacks(autoRetry);
        pageFailed = false;
        errorView.setVisibility(View.GONE);
        showSplashAgain();
        web.loadUrl(UI_URL);
    }

    /** The app ALWAYS talks to the controller by name, never by IP. */
    private String currentBase() {
        return BASE_URL;
    }

    // ---------- UI pieces ----------

    private void buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.BLACK);
        f.setClickable(true);
        // Vector logo (res/drawable/splash_logo.xml): scales to any screen with no blur/stretch.
        // Padding is recalculated on every size change so it also fits when rotated.
        ImageView iv = new ImageView(this) {
            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                int side = Math.min(w, h);
                int padX = (w - Math.round(side * 0.40f)) / 2;
                int padY = (h - Math.round(side * 0.40f * 470f / 357f)) / 2;
                setPadding(padX, padY, padX, padY);
            }
        };
        iv.setImageResource(R.drawable.splash_logo);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        splash = f;
    }

    private void buildErrorView() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.BLACK);
        int p = dp(28);
        l.setPadding(p, p, p, p);

        errorText = new TextView(this);
        errorText.setTextColor(Color.WHITE);
        errorText.setTextSize(16);
        errorText.setGravity(Gravity.CENTER);
        l.addView(errorText, new LinearLayout.LayoutParams(-1, -2));

        l.addView(makeBtn("Retry", v -> reload()));
        errorView = l;
    }

    private Button makeBtn(String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setOnClickListener(c);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void showError(String msg) {
        errorText.setText(msg);
        errorView.setVisibility(View.VISIBLE);
        hideSplash();
    }

    private void hideSplash() {
        if (splashHidden) return;
        long wait = MIN_SPLASH_MS - (System.currentTimeMillis() - splashShownAt);
        handler.postDelayed(() -> {
            splashHidden = true;
            splash.animate().alpha(0f).setDuration(350)
                    .withEndAction(() -> splash.setVisibility(View.GONE)).start();
        }, Math.max(0, wait));
    }

    private void showSplashAgain() {
        // Only used on retry: keep it simple, show splash instantly
        splashHidden = false;
        splashShownAt = System.currentTimeMillis();
        splash.animate().cancel();
        splash.setAlpha(1f);
        splash.setVisibility(View.VISIBLE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- full screen ----------

    private void goImmersive() {
        // Normal system bars on a dark background: the app now has its own header + tab bar.
        getWindow().setStatusBarColor(0xFF0B0B0D);
        getWindow().setNavigationBarColor(0xFF0B0B0D);
    }

    // ---------- lifecycle ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back && window.__back()", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        io.shutdownNow();
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
        ((ViewGroup) root).removeView(web);
        web.destroy();
        super.onDestroy();
    }
}
